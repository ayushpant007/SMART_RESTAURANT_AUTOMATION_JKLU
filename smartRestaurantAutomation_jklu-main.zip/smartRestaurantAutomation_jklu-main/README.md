# smartRestaurantAutomation_jklu
In this project we are using -> 1) Hardware like(esp32, irsensor, l298 motor driver, oled_128x64, N20 gear motors, push buttons, batteries, 2 software (working on).
